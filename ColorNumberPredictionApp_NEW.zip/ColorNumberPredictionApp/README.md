# Color Number Prediction Lab (Android)

A small native Android starter app built with Kotlin and standard Android Views. It uses a clean white interface and includes:
- A heuristic number/color guess (0–9)
- Manual recording of actual results
- On-device history saved with SharedPreferences
- Simple number-match tracking
- Clear-history control

## Color mapping used in this sample
- 0 and 5 = Violet
- Even numbers other than 0 = Red
- Odd numbers other than 5 = Green

This mapping is only a sample convention. Change `colorFor()` in `MainActivity.kt` if your game uses different rules.

## Build the APK
1. Install Android Studio on a computer: https://developer.android.com/studio
2. Extract this ZIP.
3. In Android Studio choose **Open** and select the extracted `ColorNumberPredictionApp` folder.
4. Allow Android Studio to sync Gradle. Use JDK 17 if prompted.
5. Connect an Android phone with USB debugging enabled, or create an emulator.
6. Press **Run** to install the app.
7. To make an APK: **Build → Build Bundle(s) / APK(s) → Build APK(s)**. Android Studio will show the output path, usually `app/build/outputs/apk/debug/app-debug.apk`.

## Important notes
- The guess is a transparent heuristic: it selects randomly among the least-seen numbers in the last 20 recorded results. It is not machine learning and does not improve the odds of predicting a genuinely random outcome.
- This app does not connect to any third-party game, account, or server.
- History is stored locally on the device and is not synced to a cloud account.
- This is a starter project, not a signed Play Store release. A release APK requires signing and testing.
