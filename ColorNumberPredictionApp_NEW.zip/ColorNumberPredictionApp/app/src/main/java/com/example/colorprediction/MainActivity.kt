package com.example.colorprediction

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("prediction_app", MODE_PRIVATE) }
    private val history = mutableListOf<Round>()
    private lateinit var root: LinearLayout
    private lateinit var numberInput: EditText
    private lateinit var historyBox: LinearLayout
    private lateinit var predictionCard: LinearLayout
    private lateinit var predictionText: TextView
    private lateinit var accuracyText: TextView
    private lateinit var statusText: TextView

    data class Round(
        val number: Int,
        val color: String,
        val guessNumber: Int,
        val guessColor: String,
        val timestamp: Long,
        val source: String
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        loadHistory()
        buildUi()
        renderHistory()
        showPrediction()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).roundToInt()

    private fun bg(color: Int, radius: Int = 18): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }

    private fun text(value: String, size: Float, color: Int = Color.rgb(31, 41, 55), bold: Boolean = false): TextView =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    private fun button(label: String, action: () -> Unit): Button =
        Button(this).apply {
            text = label
            isAllCaps = false
            textSize = 14f
            setOnClickListener { action() }
        }

    private fun buildUi() {
        val scroll = ScrollView(this).apply { setBackgroundColor(Color.rgb(248, 250, 252)) }
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(28))
        }
        scroll.addView(root)
        setContentView(scroll)

        root.addView(text("COLOR & NUMBER", 12f, Color.rgb(100, 116, 139), true))
        root.addView(text("Prediction Lab", 30f, Color.rgb(15, 23, 42), true).apply {
            setPadding(0, dp(4), 0, dp(4))
        })
        root.addView(text("A simple tracker for color and number guesses.", 14f, Color.rgb(100, 116, 139)))
        root.addView(space(18))

        predictionCard = card()
        predictionCard.setPadding(dp(18), dp(18), dp(18), dp(18))
        predictionCard.addView(text("NEXT GUESS", 12f, Color.rgb(100, 116, 139), true))
        predictionText = text("Preparing a guess…", 23f, Color.rgb(15, 23, 42), true)
        predictionText.setPadding(0, dp(8), 0, dp(4))
        predictionCard.addView(predictionText)
        statusText = text("Heuristic only — not a guaranteed prediction.", 12f, Color.rgb(100, 116, 139))
        predictionCard.addView(statusText)
        root.addView(predictionCard)
        root.addView(space(12))
        root.addView(button("Generate new guess") { showPrediction() }.apply {
            layoutParams = LinearLayout.LayoutParams(-1, dp(52))
        })
        root.addView(space(24))

        root.addView(text("Record an actual result", 20f, Color.rgb(15, 23, 42), true))
        root.addView(space(8))
        root.addView(text("Enter the number that appeared (0–9). The app will derive its color and save it to history.", 14f, Color.rgb(100, 116, 139)))
        numberInput = EditText(this).apply {
            hint = "Number from 0 to 9"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            filters = arrayOf(android.text.InputFilter.LengthFilter(1))
            textSize = 16f
            setSingleLine(true)
            setPadding(dp(14), dp(10), dp(14), dp(10))
            background = bg(Color.WHITE, 12)
        }
        val inputParams = LinearLayout.LayoutParams(-1, dp(54))
        inputParams.topMargin = dp(12)
        root.addView(numberInput, inputParams)
        root.addView(space(8))
        root.addView(button("Save result") { saveResult() }.apply {
            layoutParams = LinearLayout.LayoutParams(-1, dp(50))
        })
        root.addView(space(24))

        root.addView(text("History & accuracy", 20f, Color.rgb(15, 23, 42), true))
        accuracyText = text("No results recorded yet.", 14f, Color.rgb(100, 116, 139))
        accuracyText.setPadding(0, dp(6), 0, dp(12))
        root.addView(accuracyText)
        historyBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(historyBox)
        root.addView(space(10))
        root.addView(button("Clear history") { confirmClear() })
        root.addView(space(18))
        root.addView(text("Important: random game outcomes cannot be reliably predicted from past results. Guesses are illustrative, and the app does not connect to or predict any game's official server.", 12f, Color.rgb(100, 116, 139)))
    }

    private fun space(height: Int) = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(1, dp(height))
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = bg(Color.WHITE, 20)
        elevation = dp(2).toFloat()
    }

    private fun colorFor(n: Int): String = when {
        n == 0 || n == 5 -> "Violet"
        n % 2 == 0 -> "Red"
        else -> "Green"
    }

    private fun colorInt(name: String): Int = when (name) {
        "Red" -> Color.rgb(239, 68, 68)
        "Green" -> Color.rgb(22, 163, 74)
        "Violet" -> Color.rgb(139, 92, 246)
        else -> Color.GRAY
    }

    private fun showPrediction() {
        // Transparent heuristic: choose a number that has appeared least often recently;
        // ties are randomized. This is not a claim of improved odds for random games.
        val recent = history.take(20)
        val counts = (0..9).associateWith { n -> recent.count { it.number == n } }
        val minCount = counts.values.minOrNull() ?: 0
        val candidates = (0..9).filter { counts[it] == minCount }
        val guess = candidates.random()
        val color = colorFor(guess)
        predictionText.text = "$guess  •  $color"
        predictionText.setTextColor(colorInt(color))
        statusText.text = if (recent.isEmpty()) {
            "Starter guess • no history yet • heuristic only"
        } else {
            "Based on the least-seen number in the last ${recent.size} saved results. Not a reliable forecast."
        }
    }

    private fun saveResult() {
        val value = numberInput.text.toString().toIntOrNull()
        if (value == null || value !in 0..9) {
            Toast.makeText(this, "Enter a number from 0 to 9.", Toast.LENGTH_SHORT).show()
            return
        }
        val shown = predictionText.text.toString().substringBefore("  •").toIntOrNull() ?: -1
        val guessColor = predictionText.text.toString().substringAfter("• ", "")
        val round = Round(
            number = value,
            color = colorFor(value),
            guessNumber = shown,
            guessColor = guessColor,
            timestamp = System.currentTimeMillis(),
            source = "manual"
        )
        history.add(0, round)
        if (history.size > 200) history.removeAt(history.lastIndex)
        persistHistory()
        numberInput.text.clear()
        renderHistory()
        showPrediction()
        Toast.makeText(this, "Result saved.", Toast.LENGTH_SHORT).show()
    }

    private fun renderHistory() {
        if (!::historyBox.isInitialized) return
        historyBox.removeAllViews()
        val recorded = history.size
        val numberHits = history.count { it.guessNumber == it.number }
        val colorHits = history.count { it.guessColor == it.color }
        accuracyText.text = if (recorded == 0) {
            "No results recorded yet. Save a result to start tracking."
        } else {
            "Saved: $recorded   •   Number matches: $numberHits (${percent(numberHits, recorded)})   •   Color matches: $colorHits (${percent(colorHits, recorded)})"
        }
        if (history.isEmpty()) {
            historyBox.addView(card().apply {
                setPadding(dp(16), dp(16), dp(16), dp(16))
                addView(text("Your saved results will appear here.", 14f, Color.rgb(100, 116, 139)))
            })
            return
        }
        history.take(30).forEach { round ->
            val row = card().apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(14), dp(12), dp(14), dp(12))
            }
            val num = text(round.number.toString(), 24f, colorInt(round.color), true)
            row.addView(num, LinearLayout.LayoutParams(dp(38), -2))
            val details = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            details.addView(text(round.color, 14f, Color.rgb(31, 41, 55), true))
            val time = SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()).format(Date(round.timestamp))
            details.addView(text(time, 11f, Color.rgb(100, 116, 139)))
            row.addView(details, LinearLayout.LayoutParams(0, -2, 1f))
            val match = round.guessNumber == round.number
            row.addView(text(if (round.guessNumber < 0) "—" else if (match) "Number ✓" else "Number ✕", 12f,
                if (match) Color.rgb(22, 163, 74) else Color.rgb(100, 116, 139), true))
            val lp = LinearLayout.LayoutParams(-1, -2)
            lp.bottomMargin = dp(8)
            historyBox.addView(row, lp)
        }
        if (history.size > 30) {
            historyBox.addView(text("Showing latest 30 of $recorded saved results.", 12f, Color.rgb(100, 116, 139)))
        }
    }

    private fun percent(hits: Int, total: Int): String =
        if (total == 0) "0%" else "${(hits * 100.0 / total).roundToInt()}%"

    private fun persistHistory() {
        val array = JSONArray()
        history.forEach {
            array.put(JSONObject().apply {
                put("number", it.number)
                put("color", it.color)
                put("guessNumber", it.guessNumber)
                put("guessColor", it.guessColor)
                put("timestamp", it.timestamp)
                put("source", it.source)
            })
        }
        prefs.edit().putString("history", array.toString()).apply()
    }

    private fun loadHistory() {
        val raw = prefs.getString("history", null) ?: return
        try {
            val array = JSONArray(raw)
            for (i in 0 until array.length()) {
                val o = array.getJSONObject(i)
                history.add(Round(
                    o.getInt("number"), o.getString("color"),
                    o.optInt("guessNumber", -1), o.optString("guessColor", ""),
                    o.getLong("timestamp"), o.optString("source", "manual")
                ))
            }
        } catch (_: Exception) {
            history.clear()
        }
    }

    private fun confirmClear() {
        android.app.AlertDialog.Builder(this)
            .setTitle("Clear saved history?")
            .setMessage("This removes all saved results from this device.")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Clear") { _, _ ->
                history.clear()
                persistHistory()
                renderHistory()
                showPrediction()
            }.show()
    }
}
